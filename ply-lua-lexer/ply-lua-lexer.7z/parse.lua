var x = 99
var y = 100

while ( x > y ) do
    x = x - 1
    print("X is greater than Y")