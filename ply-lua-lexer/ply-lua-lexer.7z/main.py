import lexer
import parser
import sys

from sys import argv

if __name__ == '__main__':
    filename = argv[1]
    file = open(filename)
    code = file.read()


