var s = "This is a test string to be lexxed"
var x = 9
var y = 21
var mod = 19 % 8
var mult = 88 * 3
var div = 63 / 9 
var z = x + y